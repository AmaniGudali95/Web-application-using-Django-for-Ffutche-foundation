from django.contrib import admin
from .models import User
from .models import Scholarship
from .models import School
from .models import Scholarship_Donation
from .models import Student_Education
from .models import studentScholarship
from .models import Scholarship_Application

# Register your models here.
class UserAdmin(admin.ModelAdmin):
    list_display = ("username", "user_type", "first_name_1", "last_name_1")
    list_filter = ("user_type",)
    search_fields = ("username",)
admin.site.register(User, UserAdmin)

class ScholarshipAdmin(admin.ModelAdmin):
    
    list_display = ['Scholarship_Name', "Scholarship_Amount", "Academic_Year","Amount_Received" ]
    list_filter = ['Academic_Year', ]
    search_fields = ["Scholarship_Name", ]
admin.site.register(Scholarship, ScholarshipAdmin)

    
class SchoolAdmin(admin.ModelAdmin):
    list_display = ["School_Name", "Type_Of_School",]
    list_filter = ["Type_Of_School",]
    search_fields = ["School_Name","Type_Of_School", ]
admin.site.register(School, SchoolAdmin )



class Scholarship_DonationAdmin(admin.ModelAdmin):
    list_display = ["Scholarship","user", "Denomination", "Donation_Amount",]
    list_filter = ["Scholarship","user"]
    search_fields = ["Scholarship","user"]
admin.site.register(Scholarship_Donation, Scholarship_DonationAdmin)



class Student_EducationAdmin(admin.ModelAdmin):
    list_display = ["user", "Grade", "Rank", "Terminated"]
    list_filter = ["Grade"]
    search_fields = ["user"]
admin.site.register(Student_Education, Student_EducationAdmin)



admin.site.register(studentScholarship)


class Scholarship_ApplicationAdmin(admin.ModelAdmin):
    list_display = ["user", "Scholarship"]
    list_filter = ["Scholarship", ]

admin.site.register(Scholarship_Application, Scholarship_ApplicationAdmin)
