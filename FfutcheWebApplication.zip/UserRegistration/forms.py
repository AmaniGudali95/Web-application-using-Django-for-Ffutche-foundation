from django import forms    
from UserRegistration.models import User
from UserRegistration.models import Scholarship_Donation
from UserRegistration.models import Student_Education
from UserRegistration.models import Scholarship_Application
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Submit, Layout
from django.forms import Form

class DateInput(forms.DateInput):
    input_type = 'date'

class DonorSignUpForm(forms.ModelForm):
    class Meta(): 
        model = User
        fields = ("username","password","first_name_1","middle_name_1","last_name_1", "sex", "email", "phone1", "phone2","address_line_1","address_line_2","city", "state_or_province","country", )
        widgets = {
        'password': forms.PasswordInput(),
        
        
    }

class DonorForm(forms.ModelForm):
    class Meta(): 
        model = User
        fields = ("username","address_line_2","city", "state_or_province","country" )   


class ApplicantSignUpForm(forms.ModelForm):
    class Meta(): 
        model = User
        fields = "__all__"
        widgets = {
        'password': forms.PasswordInput(),
        'date_of_birth' : DateInput(),
        
    }

class ApplicantForm(forms.ModelForm):
    class Meta(): 
        model = User
        fields = ("username","address_line_1","address_line_2","city", "state_or_province","country",)   

class ScholarshipDonationForm(forms.ModelForm):
    Donation_Amount = forms.DecimalField(min_value=100.00)
    class Meta(): 
        model = Scholarship_Donation
        exclude = ("user",)


class StudentEducationForm(forms.ModelForm):

    class Meta():
        model = Student_Education
        exclude = ("user",)


class StudentApplicationForm(forms.ModelForm):
    class Meta():
        model = Scholarship_Application
        exclude = ("user",)