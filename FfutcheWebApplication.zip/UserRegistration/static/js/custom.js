$(document).ready(function(){

    $("#add").click(function (e){
    
        $('#items').append('<div><{{ form.occupation}}>>'+
            '<input type ="button" value = "delete" id = "delete"/></div>');
    
    });
    
    $('body').on('click','#delete', function (e){
        $(this).parent('div').remove();
    });
    
    });