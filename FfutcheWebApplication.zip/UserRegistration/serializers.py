from rest_framework import serializers
class studentScholarshipSerializer(serializers.Serializer):
    scholarshipID=serializers.CharField(max_length=100)
    AwardedOn=serializers.DateField()
    deliveryMethod=serializers.CharField()
    awardJustification=serializers.CharField()