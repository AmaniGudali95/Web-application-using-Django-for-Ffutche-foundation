from django.shortcuts import render

from UserRegistration.forms import ApplicantSignUpForm
from UserRegistration.forms import ApplicantForm
from UserRegistration.forms import DonorForm
from UserRegistration.forms import DonorSignUpForm
from UserRegistration.forms import ScholarshipDonationForm
from UserRegistration.forms import StudentEducationForm
from UserRegistration.forms import StudentApplicationForm
from UserRegistration.models import studentScholarship
from .serializers import studentScholarshipSerializer
from .models import User,Scholarship,Scholarship_Application


from django.forms.formsets import formset_factory,ManagementForm
from rest_framework import status
from rest_framework.response import Response
from rest_framework.renderers import TemplateHTMLRenderer,JSONRenderer
from rest_framework.decorators import api_view,renderer_classes
import django.forms.formsets
#from .serializers import studentScholarshipSerializer
from rest_framework.response import Response
from rest_framework.renderers import TemplateHTMLRenderer,JSONRenderer
from rest_framework.decorators import api_view,renderer_classes



# Create your views here.



@api_view(['GET', 'POST'])
@renderer_classes([TemplateHTMLRenderer])
def index (request):
        if request.method == 'POST':
                if(User.objects.filter(username=request.POST['uname']).exists()):
                        dObj=User.objects.get(username=request.POST['uname'])
                        return Response({'Details':dObj}, template_name='UserRegistration/index.html')
                else:
                        return render(request, 'UserRegistration/index.html')  
        return render(request, 'UserRegistration/index.html')



def signup(request):
        form = DonorSignUpForm()
        form2 = DonorForm()
        

        if request.method == 'POST':
            form = DonorSignUpForm(request.POST)
            form2 = DonorForm(request.POST)
        
            if(form.is_valid() and form2.is_valid()):
                    user = form.save(commit=False)
                    user.donor = form2.save()
                    user.save()
              
                    usrObj=User.objects.get(username=request.POST['username'])
                    usrObj.user_type='Donor'
                               #user.user_type='donor'
                    usrObj.save()    

                    return render(request, 'UserRegistration/donorsignupsuccess.html') 

        
            else:
                     print('FORM IS INVALID') 
        return render(request, 'UserRegistration/donorsignup.html', {'form':form, 'form2':form2})


def applicant_signup(request):
        EducationFormSet = formset_factory(StudentEducationForm,extra= 3,max_num=1, validate_min=True)
        form = ApplicantSignUpForm()
        form2 = ApplicantForm()
        formset1 = EducationFormSet()        

        if request.method == 'POST':
                form = ApplicantSignUpForm(request.POST)
                form2 = ApplicantForm(request.POST)
                formset1 = EducationFormSet(request.POST)

                if(form.is_valid() and form2.is_valid()):
                        user = form.save(commit=False)
                        user.donor = form2.save()
                        user.save()
              
                        usrObj=User.objects.get(username=request.POST['username'])
                        usrObj.user_type='Applicant'
                               #user.user_type='donor'
                        usrObj.save()  
                        if (formset1.is_valid()):
                                for inline_form in formset1:
                                        if inline_form.cleaned_data:
                                                education = inline_form.save(commit=False)
                                                education.user = user
                                                education.save()
                 
                                return render(request, 'UserRegistration/appsignupsuccess.html') 
    
            
        return render(request, 'UserRegistration/applicantsignup.html', {'form':form, 'form2':form2, 'formset1':formset1})


#login views

@api_view(['GET', 'POST'])
@renderer_classes([TemplateHTMLRenderer])
def loginForm(request):
        return render(request,'UserRegistration/Login.html')

@api_view(['GET', 'POST'])
@renderer_classes([TemplateHTMLRenderer])
def login(request):
    if(request.method=='POST'):
        if(User.objects.filter(username=request.POST['uname']).exists()):
                dObj=User.objects.get(username=request.POST['uname'])
                if(dObj.user_type=='Donor'):
                        return Response({'Details':dObj},template_name='UserRegistration/index.html')

                else:
                        return Response({'Details':dObj},template_name='UserRegistration/index.html')
        
        else:
                print('FORM IS INVALID')


#donation view

@api_view(['GET', 'POST'])
@renderer_classes([TemplateHTMLRenderer])
def s_donors (request):
        dObj=User.objects.get(username=request.POST['uname'])
        DonationFormSet = formset_factory(ScholarshipDonationForm, validate_min=True)   
        
        formset1 = DonationFormSet()      
        

        if request.method == 'POST':
                formset1 = DonationFormSet(request.POST)

                if (formset1.is_valid()):
                        for inline_form in formset1:
                                if inline_form.cleaned_data:
                                        donation = inline_form.save(commit=False)
                                        donation.user = dObj
                                        donation.save()
                                        scholarshipObj=Scholarship.objects.get(Scholarship_Name=donation.Scholarship)
                                        scholarshipObj.Amount_Received=scholarshipObj.Amount_Received+donation.Donation_Amount
                                        scholarshipObj.save()
                                   
                        return Response({'Details':dObj},template_name='UserRegistration/success.html') 

@api_view(['GET', 'POST'])
@renderer_classes([TemplateHTMLRenderer])
def s_donorsFormView(request):
        if(request.method=='POST' and User.objects.filter(username=request.POST['uname']).exists()):
                        dObj=User.objects.get(username=request.POST['uname'])
                        DonationFormSet = formset_factory(ScholarshipDonationForm, validate_min=True)
                        #form = DonorSignUpForm()
                        formset1 = DonationFormSet()
                        return Response({'Details':dObj, 'formset1': formset1}, template_name='UserRegistration/sdonation.html')
        else:
                DonationFormSet1 = formset_factory(ScholarshipDonationForm, validate_min=True)

                form = DonorSignUpForm()
                form2 = DonorForm()
                formset1 = DonationFormSet1()
                                
                return Response({'form':form, 'form2': form2, 'formset1':formset1}, template_name='UserRegistration/donorsignup_donation.html')

                #return render(request, 'UserRegistration/donorsignup_donation.html', {'form':form, 'form2':form2,'formset1': formse1})


#apply button


@api_view(['GET', 'POST'])
@renderer_classes([TemplateHTMLRenderer])
def Applicant_action (request):
        if request.method == 'POST':
                if(User.objects.filter(username=request.POST['uname']).exists()):                                
                        dObj=User.objects.get(username=request.POST['uname'])
                        return Response({'Details':dObj},template_name='UserRegistration/Applicant_action.html')

        return render(request, 'UserRegistration/Applicant_action.html')


@api_view(['GET', 'POST'])
@renderer_classes([TemplateHTMLRenderer])
def applicant_FormView(request):
       dObj=User.objects.get(username=request.POST['uname'])
       ApplyFormset = formset_factory(StudentApplicationForm, validate_min=True)
       formset2 = ApplyFormset()
       return Response({'Details':dObj, 'formset2': formset2}, template_name='UserRegistration/applyscholarship.html')     

@api_view(['GET', 'POST'])
@renderer_classes([TemplateHTMLRenderer])
def applicant_application (request):
        dObj=User.objects.get(username=request.POST['uname'])
        ApplyFormset = formset_factory(StudentApplicationForm, validate_min=True)
                
        formset2 = ApplyFormset()
        
        

        if request.method == 'POST':
                
                formset2 = ApplyFormset(request.POST or None)
        
        
                if (formset2.is_valid()):

                        for inline_form in formset2:
                                if inline_form.cleaned_data:
                                        application = inline_form.save(commit=False)
                                        application.user = dObj
                                        application.save()                                   

                                   
                        return Response({'Details':dObj}, template_name='UserRegistration/applysuccess.html') 


@api_view(['GET', 'POST'])
@renderer_classes([TemplateHTMLRenderer])
def application_status(request):
    if(request.method=='POST'):
        if(User.objects.filter(username=request.POST['uname']).exists()):
                dObj=User.objects.get(username=request.POST['uname'])
                detail=studentScholarship.objects.get(username__username__exact=request.POST['uname'])
                serializer=studentScholarshipSerializer(detail)
                return Response({'Details2':serializer.data, 'Details' :dObj },template_name='UserRegistration/UserStatus.html')
        else:
                return render(request, 'UserRegistration/notsignedin.html') 

@api_view(['GET', 'POST'])
@renderer_classes([TemplateHTMLRenderer])
def Donate_Signup(request):
    if(request.method=='POST'):
                        DonationFormSet1 = formset_factory(ScholarshipDonationForm, validate_min=True)
                        form = DonorSignUpForm()
                        form2 = DonorForm()
                        formset1 = DonationFormSet1()
                        
                        form = DonorSignUpForm(request.POST or None)
                        form2 = DonorForm(request.POST or None)
                        formset1 = DonationFormSet1(request.POST or None)

                        if(form.is_valid() and form2.is_valid()):
                                user = form.save(commit=False)
                                user.donor = form2.save()
                                user.save()
              
                                usrObj=User.objects.get(username=request.POST['username'])
                                usrObj.user_type='Donor'
                                usrObj.save()
                                if (formset1.is_valid()):
                                        for inline_form in formset1:
                                                if inline_form.cleaned_data:
                                                        donation = inline_form.save(commit=False)
                                                        donation.user = user
                                                        donation.save()    
                                                        scholarshipObj=Scholarship.objects.get(Scholarship_Name=donation.Scholarship)
                                                        scholarshipObj.Amount_Received=scholarshipObj.Amount_Received+donation.Donation_Amount
                                                        scholarshipObj.save() 
                                        return Response({'Details':usrObj},template_name='UserRegistration/success.html') 

        
def Scholarship_List(request):
        schObj=Scholarship.objects.all()
        return render(request,'UserRegistration/ListOfScholarships.html',{'Details':schObj})
