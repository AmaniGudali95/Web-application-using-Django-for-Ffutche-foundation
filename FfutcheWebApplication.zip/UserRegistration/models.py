from django.db import models
from django_countries.fields import CountryField
from phonenumber_field.modelfields import PhoneNumberField
import datetime
from django.core.validators import MaxValueValidator, MinValueValidator
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

# Create your models here.

User_Choices = (
    ('choose','CHOOSE'),
    ('donor','DONOR'),
    ('applicant','APPLICANT'),
    ('guardian','Applicant_Guardian')
     )

Studies_Choices = (
    ('kindergarten ','Kindergarten'),
    ('elementary ','Elementary'),
    ('middleschool', 'Middle School'),
    ('highschool', 'High School'),
    ('undergraduate', 'Undergraduate'),
    ('masters', 'Masters'),
)

School_Choices = (
    ('kindergarten ','Kindergarten'),
    ('elementary ','Elementary'),
    ('middleschool', 'Middle School'),
    ('highschool', 'High School'),
    ('college', 'College'),
    ('university', 'University'),
)

Scholarship_study_choices = (
    ('general ','General'),
    ('kindergarten ','Kindergarten'),
    ('elementary ','Elementary'),
    ('middleschool', 'Middle School'),
    ('highschool', 'High School'),
    ('college', 'College'),
    ('university', 'University'),
)


YEAR_CHOICES = []
for r in range(2011, (datetime.datetime.now().year+5)):
    YEAR_CHOICES.append((r,r))

Sex_Choices = (
    ('male','Male'),
    ('female', 'Female')
)

Marital_Choices = (
    ('single','Single'),
    ('married','Married'),
    ('seperated','Seperated'),
    ('divorced', 'Divorced'),
    ('widow','Widow'),
    )

Terminated_Choices= (
    ('yes','Yes'),
    ('no','No' ),
)

parent_choices = (
    ('father', 'Father'),
    ('mother', 'Mother'),
)

status_choices = (
    ('Awarded', 'Awarded'),
    ('rejected', 'Rejected'),
    ('inreview', 'Under Review')

)
class User(models.Model):
    user_type = models.CharField(max_length = 250, blank = True)
    username=models.CharField(max_length=150, unique=True, primary_key= True )
    password = models.CharField(max_length=50, default = '')
    first_name_1 = models.CharField(verbose_name='First Name', max_length = 250, null = True)
    middle_name_1 = models.CharField(verbose_name='Middle Name', max_length = 250, blank = True, null = True)
    last_name_1 = models.CharField(verbose_name='Last Name',max_length = 250,null=True)
    address_line_1 = models.CharField(max_length = 250,null=True)
    address_line_2 = models.CharField(max_length = 250, default='',blank = True )
    city = models.CharField(max_length = 250, default='')
    state_or_province= models.CharField(max_length = 250, default='')
    country = CountryField(default='')
    email = models.EmailField(max_length=70)
    phone1 = PhoneNumberField(null=False, blank=False, default='')
    phone2 = PhoneNumberField(null=False, blank=True, default='')
    sex = models.CharField(max_length=10, choices=Sex_Choices, default='male')
    date_of_birth = models.DateField(null=True)
    city_of_birth = models.CharField(max_length = 250, default='')
    state_or_province_of_birth = models.CharField(max_length = 250, default='')
    country_of_birth = CountryField(default='')
    marital_status = models.CharField(max_length = 150, choices=Marital_Choices, default='single')
    employer_Name = models.CharField(max_length = 250, null=True, blank=True)
    from_date = models.DateField(null=True, blank=True)
    to_date = models.DateField(null=True, blank=True)
    Title = models.CharField(max_length = 250, default='',blank=True)
    Responsibilities = models.TextField(default='', blank=True)

    #Parent Information
    parent_1 = models.CharField(verbose_name='Parent',max_length = 250, choices=parent_choices, default='father',)
    first_name_2 = models.CharField(verbose_name='First Name', max_length = 250, null = True)
    middle_name_2 = models.CharField(verbose_name='Middle Name',max_length = 250, blank = True, null = True)
    last_name_2 = models.CharField(verbose_name='Last Name',max_length = 250,null=True)
    occupation_2 = models.CharField(verbose_name='Occupation',max_length = 250, default='', blank=True)
    employer_Name_2 = models.CharField(verbose_name='Employer Name', max_length = 250, null=True, blank=True)
    parent_2 = models.CharField(verbose_name='Parent',max_length = 250, choices=parent_choices, default='father',)
    first_name_3 = models.CharField(verbose_name='First Name', max_length = 250, null = True)
    middle_name_3 = models.CharField(verbose_name='Middle Name', max_length = 250, blank = True, null = True)
    last_name_3 = models.CharField(verbose_name='Last Name', max_length = 250,null=True)
    occupation_3 = models.CharField(verbose_name='Occupation',max_length = 250, default='', blank=True)
    employer_Name_3 = models.CharField(verbose_name='Employer Name', max_length = 250, null=True, blank=True)
        #student revenue
    Academic_Year = models.IntegerField(('year'), max_length=4, choices=YEAR_CHOICES, default=datetime.datetime.now().year)
    Parents_support = models.DecimalField(max_digits=10, decimal_places=2, blank = True, null=True)
    Loan_taken_for_the_year = models.DecimalField(max_digits=10, decimal_places=2, blank = True, null=True)
    School_break_activities = models.DecimalField(max_digits=10, decimal_places=2, blank = True, null=True)
    Scholarship = models.DecimalField(max_digits=10, decimal_places=2, blank = True, null=True)
    Others = models.DecimalField(max_digits=10, decimal_places=2, blank = True, null=True)





class Scholarship(models.Model):
    Scholarship_Name = models.CharField(max_length = 250)
    Denomination = models.CharField(max_length=4)
    Scholarship_Amount = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null = True)
    Referred_Studies = models.CharField(max_length = 250, choices=Scholarship_study_choices, default='elementary')
    Academic_Year = models.IntegerField(('year'), max_length=4, choices=YEAR_CHOICES, default=datetime.datetime.now().year)
    Description = models.TextField() # Need to be text area
    Criteria = models.TextField(default='')
    Amount_Received = models.DecimalField(max_digits=10, decimal_places=2, default = '0')

    def __str__(self):
        return self.Scholarship_Name
    

class School(models.Model):
    School_Name = models.CharField(max_length = 250)
    School_Address = models.CharField(max_length = 250)
    City = models.CharField(max_length = 250)
    Country = CountryField()
    Type_Of_School = models.CharField(max_length = 250, choices=School_Choices, default='elementary')   
    Contact_Person_Name = models.CharField(max_length = 250)
    Contact_Phone_1= PhoneNumberField(null=False, blank=False, default='')
    Contact_Phone_2= PhoneNumberField(null=False, blank=False, default='')

    def __str__(self):
        return self.School_Name

class Scholarship_Donation(models.Model):
    Scholarship = models.ForeignKey(Scholarship, on_delete=models.CASCADE, default='')
    user = models.ForeignKey(User, on_delete=models.CASCADE, default = 1)
    Denomination = models.CharField(max_length=4)
    Donation_Amount = models.DecimalField(validators=[MinValueValidator(100.00)],max_digits=10, decimal_places=2)
    
    class Meta:
        verbose_name = 'Scholarship Donation'

   

class Student_Education(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, default = '')
    Degree = models.CharField(max_length = 250, choices=Studies_Choices, default='elementary')
    School = models.ForeignKey(School, on_delete=models.CASCADE, default = 1)
    Year_Attended = models.IntegerField(('year'))
    Class = models.CharField(max_length = 250, blank=True)
    Grade = models.CharField(max_length = 250)
    Rank =  models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    Skills_and_Achievements = models.TextField(default='', blank=True)
    Terminated = models.CharField(max_length=5, choices=Terminated_Choices, default='no')
    Reason_for_Termination = models.TextField(default='', blank=True)

    class Meta:
        verbose_name = 'Student Education'

    

class Scholarship_Application(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    Scholarship=models.ForeignKey(Scholarship,on_delete=models.CASCADE)
    Year=models.IntegerField(('year'), max_length=4, choices=YEAR_CHOICES, default=datetime.datetime.now().year)

    class Meta:
        verbose_name = 'Student Application'
    
   

class studentScholarship(models.Model):
    username=models.ForeignKey(User,on_delete=models.CASCADE)
    scholarshipID=models.ForeignKey(Scholarship,on_delete=models.CASCADE)
    Status = models.CharField(max_length=100,choices=status_choices, default='inreview')
    AwardedOn=models.DateField(blank = True, null=True)
    deliveryMethod=models.CharField(max_length=100,primary_key=False, blank = 'true')
    awardJustification=models.TextField(blank = 'true')

    class Meta:
        verbose_name = 'Student Scholarship Statuse'

    
